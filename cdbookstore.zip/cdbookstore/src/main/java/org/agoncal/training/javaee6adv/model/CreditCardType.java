package org.agoncal.training.javaee6adv.model;

public enum CreditCardType
{
   VISA, MASTER_CARD, AMERICAN_EXPRESS
}