package org.agoncal.training.javaee6adv.model;

public enum Language
{
   ENGLISH, FRENCH, SPANISH, PORTUGUESE, ITALIAN, FINISH, GERMAN, DEUTSCH, RUSSIAN
}